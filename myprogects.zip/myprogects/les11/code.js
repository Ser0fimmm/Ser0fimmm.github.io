alert(!!( a && b ))
alert((a && b))